package com.example.myinterface;

import android.annotation.SuppressLint;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * to handle interaction events.
 * Use the {@link Pictfragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Pictfragment extends Fragment implements View.OnClickListener{
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    String hostname;
    String num;


    View v;
    TextView textView;
    Button button;
    ImageView imageView;

    public Pictfragment() {

    }

    @SuppressLint("ValidFragment")
    public Pictfragment(String hostname,String num) {
        this.hostname=hostname;
        this.num=num;
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Pictfragment.
     */
    // TODO: Rename and change types and number of parameters
    public static Pictfragment newInstance(String param1, String param2) {
        Pictfragment fragment = new Pictfragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        v = inflater.inflate(R.layout.fragment_pictfragment, container, false);
        button = v.findViewById(R.id.buttonPicture);
        textView = v.findViewById(R.id.pictureTextViewResponse);
        imageView= v.findViewById(R.id.imageViewFromServer);

        imageView.setOnClickListener(this);
        textView.setOnClickListener(this);
        button.setOnClickListener(this);

        return v;
    }



    @SuppressLint("ResourceType")
    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.buttonPicture:
                textView.setText("adadaad");
                String src="https://im.haberturk.com/2018/07/19/2065738_4077baf91c311373d9166a49c513fe72_640x640.jpg";
                URL url = null;
                try {
                    url = new URL(src);
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                }
                HttpURLConnection connection  = null;
                try {
                    connection = (HttpURLConnection) url.openConnection();
                } catch (IOException e) {
                    e.printStackTrace();
                }

                InputStream is = null;
                try {
                    is = connection.getInputStream();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                Bitmap img = BitmapFactory.decodeStream(is);

                imageView.setImageBitmap(img);

                /*
                getImageData runnable = new getImageData();
                //System.out.println(editText.getText().toString());
                new Thread(runnable).start();*/
                break;
        }
    }




    class getImageData implements Runnable {
        String data;
        void getImageData() throws IOException {
            String src="https://im.haberturk.com/2018/07/19/2065738_4077baf91c311373d9166a49c513fe72_640x640.jpg";
            URL url = new URL(src);
            HttpURLConnection connection  = (HttpURLConnection) url.openConnection();

            InputStream is = connection.getInputStream();
            Bitmap img = BitmapFactory.decodeStream(is);

            imageView.setImageBitmap(img);

        }
        void setData(){
            OkHttpClient client = new OkHttpClient();
            String url = hostname+"/getImage";

            Request request = new Request.Builder()
                    .url(url)
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    e.printStackTrace();
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (response.isSuccessful()) {
                        System.out.println("succces :"+response.body().string());
                    }
                }
            });
            //return myResponse[0];
        }

        @Override
        public void run() {
            try {
                getImageData();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
