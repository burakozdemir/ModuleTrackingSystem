package com.example.myinterface;

import android.Manifest;
import android.content.pm.PackageManager;
import android.location.Location;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback,
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener,
        LocationListener {

    GoogleMap mMap;
    GoogleApiClient googleApiClient;
    Marker before ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        LatLng pp= new LatLng(40.808, 29.356);
        MarkerOptions options = new MarkerOptions();
        options.position(pp).title("Burak Özdemir");
        before = mMap.addMarker(options);
        mMap.moveCamera(CameraUpdateFactory.newLatLng(pp));

        LatLngBounds.Builder builder = new LatLngBounds.Builder();
        builder.include(options.getPosition());
        LatLngBounds bounds = builder.build();
        //CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds,-20);
        googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(pp.latitude, pp.longitude), 16.0f));
    }

    public void changeLocation(){
        if(before!=null )
            before.setVisible(false);
    }

    public void addMarker(double x,double y){
        LatLng pp= new LatLng(x, y);
        MarkerOptions options = new MarkerOptions();
        options.position(pp).title("Burak Özdemir");
        before = mMap.addMarker(options);
        mMap.moveCamera(CameraUpdateFactory.newLatLng(pp));

        LatLngBounds.Builder builder = new LatLngBounds.Builder();
        builder.include(options.getPosition());
        LatLngBounds bounds = builder.build();
        //CameraUpdate cu = CameraUpdateFactory.newLatLngBounds(bounds,-20);
        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(pp.latitude, pp.longitude), 16.0f));
    }

    ///////////////////////////8
    @Override
    public void onLocationChanged(Location location) {
        //mMap.clear();
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {

    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }
}
