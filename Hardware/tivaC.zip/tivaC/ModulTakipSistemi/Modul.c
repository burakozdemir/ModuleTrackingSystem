/*
 * Modul.c
 *
 *  Created on: 11 May 2019
 *      Author: xyz
 */

#include "Modul.h"

void Int_Camera(void){
    sendUartString(console,"camera-in\n");
    while(UARTCharsAvail(cameraUart)){
        char temp=UARTCharGetNonBlocking(cameraUart);
        sendUartString(console, temp);
        sendUartString(console, ",");
        //recieveMessage[cameraIndex++] = UARTCharGetNonBlocking(cameraUart);
    }
    //recieveMessage[cameraIndex] = '\0';
    //SendStr(UART0_BASE, " IN_DATA: ");
    //sendUartString(console, cameraResponse);

    cameraIndex = 0;
    UARTIntClear(cameraUart, UART_INT_RX);
    sendUartString(console,"camera-out\n");
}

void Int_PressControl(void){

    if (GPIOIntStatus(GPIO_PORTF_BASE, false) & GPIO_PIN_4) {
       switch(callStatusFlag){
              case 0:
                  sendUartString(console,"making call\n");
                  makeCall();
                  break;
              case 1:
                  sendUartString(console,"answerCall\n");
                  answerCall();
                  break;
       }
       GPIOIntClear(GPIO_PORTF_BASE, GPIO_PIN_4);
    }
}


void Int_PostDataTimer(void){
    sendUartString(console,"callStatFlag:");
    char c[3];sprintf(c,"%d",callStatusFlag);
    sendUartString(console,c);
    sendUartString(console,"\n");

    UARTDisable(UART2_BASE);
    TimerDisable(TIMER0_BASE,TIMER_A);

    int a=callStatusFlag;
    int b = gpsFlagControl;

    if(callStatusFlag==0){

        //TimerIntClear(TIMER1_BASE,TIMER_TIMA_TIMEOUT);

        int pulseRes=pulse*2;
        if(pulseRes<10) pulseRes=10;
        if(pulseRes>100) pulseRes=99;
        char c[2];sprintf(c,"%d",pulseRes);
        sendUartString(console,c);sendUartString(console,"\n");

        postDataToInterface(latitudeResult, longitudeResult, c);
        //postDataToServer(latitudeResult,longitudeResult,c);
        //postDataToServer("40.656555","29.689734","46");

        sendUartString(console,"PostDataTimer:");
        sendUartString(console,latitudeResult);sendUartString(console,",");
        sendUartString(console,longitudeResult);sendUartString(console,",");
        char s[5];sprintf(s,"%ld",pulseRes);
        sendUartString(console,s);
        sendUartString(console, "\n");
        pulse=0;

        /*
         * posttan sonra sim900 u text moduna almayı dene
         *
         * */

    }else{
        sendUartString(console,"NO POST DATA TO SERVER \n");
    }

    TimerIntClear(TIMER1_BASE,TIMER_TIMA_TIMEOUT);
    TimerEnable(TIMER0_BASE,TIMER_A);
    UARTEnable(UART2_BASE);
}

void Int_PulseTimer(void){
    TimerIntClear(TIMER0_BASE,TIMER_TIMA_TIMEOUT);

    ADCProcessorTrigger(ADC0_BASE, 3);
    while(!ADCIntStatus(ADC0_BASE, 3, false)){}
    ADCIntClear(ADC0_BASE, 3);
    ADCSequenceDataGet(ADC0_BASE, 3, AdcValues);

    int res = (int)AdcValues[0];
    if(res>PULSETHRESHOLD){
        pulse++;
    }
    char s[11];
    sprintf(s,"%ld\n",res);
    sendUartString(console,s);
    sendUartString(console, "\n");
}


void Int_sim900(void){
    //sendUartString(console,"sim900-in\n");

    //TimerDisable(TIMER1_BASE,TIMER_A);
    UARTDisable(UART2_BASE);
    TimerDisable(TIMER0_BASE,TIMER_A);

    while(UARTCharsAvail(sim900Uart)){
            //sendUartString(console, "sim900 chargetbefore\n");
            recieveMessage[sim900Index++] = UARTCharGetNonBlocking(sim900Uart);
            //sendUartString(console, "sim900 chargetafter\n");
            SysCtlDelay(1);

    }
    recieveMessage[sim900Index] = '\0';
    //SendStr(UART0_BASE, " IN_DATA: ");
    sendUartString(console, recieveMessage);

    if(isCall(recieveMessage)){
        ledLight(BLUE_LED, 700);
        //answerCall();
    }
    if(isNo(recieveMessage)){
        ledLight(GREEN_LED, 100);
    }
    if(isCircleSet(recieveMessage)){
        circleFlag='y';
        sendUartString(console, "Set Circle Size");
    }

    readFlag = 1;
    sim900Index = 0;
    UARTIntClear(sim900Uart, UART_INT_RX);
    //TimerEnable(TIMER1_BASE,TIMER_A);
    UARTEnable(UART2_BASE);
    TimerEnable(TIMER0_BASE,TIMER_A);
    //sendUartString(console,"sim900-out\n");

}

int isCircleSet(char *message){
    char temp[5];
    int index=0;
    int result=0;
    while(*message!='\0'){
        if(*message=='@'){
            while(*message!='\0'){
                if(*message=='$') break;
                temp[index]=*message;
                index++;
                message++;
            }
            sscanf(temp, "%d", &circleSize);
            sendUartString(console, "CIRCLESETSUCCES\n");
            return 1;
        }
        else message++;
    }
    return 0;
}

int isNo(char *message){
    while(*message!='\0'){
        if(*message=='N'){
            message++;
            if(*message=='O'){
                callStatusFlag=0;
                char c[3];sprintf(c,"%d",callStatusFlag);
                sendUartString(console,"callStatusFlag: ");
                sendUartString(console,c);
                sendUartString(console,"\n");
                return 1;
            }else return 0;
        }
        else message++;
    }
    return 0;
}

int isCall(char *message){
    while(*message!='\0'){
        if(*message=='R'){
            message++;
            if(*message=='I'){
                message++;
                if(*message=='N'){
                    message++;
                    if(*message=='G'){
                        callStatusFlag=1;
                        sendUartString(console,"callFlag : ");
                        char c[3];sprintf(c,"%d",callStatusFlag);
                        sendUartString(console,c);sendUartString(console,"\n");


                        return 1;
                    }else return 0;
                }
            }
        }
        else message++;
    }
    return 0;
}

void ledLight(uint8_t led,int millisec){
    GPIOPinWrite(GPIO_PORTF_BASE , GREEN_LED ,0x0);
    GPIOPinWrite(GPIO_PORTF_BASE , BLUE_LED ,0x0);
    GPIOPinWrite(GPIO_PORTF_BASE , RED_LED ,0x0);

    GPIOPinWrite(GPIO_PORTF_BASE , led ,led);
    SysCtlDelay((SysCtlClockGet()/3000)*millisec);//
    GPIOPinWrite(GPIO_PORTF_BASE , led, 0x0);
    SysCtlDelay((SysCtlClockGet()/3000)*millisec);//
}

void hangsUpCall(){
    char msj2[]="ATH\r\n";
    sendUartString(sim900Uart,msj2);
    callStatusFlag=0;
    sendUartString(console,"callStatusFlag : ");
    char c[3];sprintf(c,"%d",callStatusFlag);
    sendUartString(console,c);sendUartString(console,"\n");

    GPIOPinWrite(GPIO_PORTF_BASE , BLUE_LED ,0x0);
}

void answerCall(){
    sendUartString(console, "answerCall\n");
    GPIOPinWrite(GPIO_PORTF_BASE , BLUE_LED ,BLUE_LED);
    char msj1[32]="AT+CLIP=1\r\n";
    char msj2[32]="ATA\r\n";
    //sendUartString(sim900Uart,msj1);
    //SysCtlDelay((SysCtlClockGet()/3000)*100);//
    sendUartString(sim900Uart,msj2);
    SysCtlDelay((SysCtlClockGet()/3000)*100);//
    callStatusFlag=2;

    sendUartString(console,"callStatusFlag : ");
    char c[3];sprintf(c,"%d",callStatusFlag);
    sendUartString(console,c);sendUartString(console,"\n");


    //sendUartString(sim900Uart, "AT\r\n");
    //SysCtlDelay(20000000);
}

void makeCall(){
    GPIOPinWrite(GPIO_PORTF_BASE , GREEN_LED ,0x0);
    GPIOPinWrite(GPIO_PORTF_BASE , BLUE_LED ,BLUE_LED);
    char msj1[]="ATD+ +905511934084;\r\n";
    char msj2[]="ATH\r\n";
    sendUartString(sim900Uart,"AT\r\n");
    SysCtlDelay((SysCtlClockGet()/3000)*1000);//
    sendUartString(sim900Uart,msj1);
    callStatusFlag=1;
    sendUartString(console,"callStatusFlag : ");
    char c[3];sprintf(c,"%d",callStatusFlag);
    sendUartString(console,c);sendUartString(console,"\n");
    SysCtlDelay((SysCtlClockGet()/3000)*2000);//
    SysCtlDelay((SysCtlClockGet()/3000)*20000);//20 saniye boyunca arama gerceklestırecek
    sendUartString(sim900Uart,msj2);
    GPIOPinWrite(GPIO_PORTF_BASE , BLUE_LED ,0x0);
    callStatusFlag=0;
    sendUartString(console,"callStatusFlag : ");
    sprintf(c,"%d",callStatusFlag);
    sendUartString(console,c);sendUartString(console,"\n");
}

void postDataToInterface(char * lat,char * lon, char * pulse){
    sendUartString(console,"postFunct\n");
    sendUartString(console,"lat:");sendUartString(console,lat);
    sendUartString(console,"lon:");sendUartString(console,lon);
    sendUartString(console,"pulse:");sendUartString(console,pulse);
    sendUartString(console,"\n");

    GPIOPinWrite(GPIO_PORTF_BASE , GREEN_LED ,0x0);
    GPIOPinWrite(GPIO_PORTF_BASE , BLUE_LED ,0x0);
    GPIOPinWrite(GPIO_PORTF_BASE , RED_LED ,0x0);
    GPIOPinWrite(GPIO_PORTF_BASE , RED_LED ,RED_LED);
    GPIOPinWrite(GPIO_PORTF_BASE , GREEN_LED ,GREEN_LED);
    GPIOPinWrite(GPIO_PORTF_BASE , BLUE_LED ,BLUE_LED);

    char msj1[]="AT+CMGF=1\r";
    char msj2[]="AT + CMGS = \"+905511934084\"\r\n";
    char data[24];
    memset(data,1,sizeof(data));int var;
    for (var = 0; var < 9; ++var) {
        data[var]=*lat;
        lat++;
    }
    data[var]=',';var++;
    for (var = var; var < 19; ++var) {
        data[var]=*lon;
        lon++;
    }
    data[var]=',';var++;
    for (var = var; var < 22; ++var) {
        data[var]=*pulse;
        pulse++;
    }

    data[22]='\r';data[23]='\n';

    sendUartString(sim900Uart,msj1);
    SysCtlDelay((SysCtlClockGet()/3000)*1000);//
    sendUartString(sim900Uart,msj2);
    SysCtlDelay((SysCtlClockGet()/3000)*1000);//
    sendUartString(sim900Uart,data);
    SysCtlDelay((SysCtlClockGet()/3000)*1000);//
    UARTCharPutNonBlocking(sim900Uart,(char)26);
    UARTCharPutNonBlocking(sim900Uart,'\r');
    UARTCharPutNonBlocking(sim900Uart,'\n');
    SysCtlDelay((SysCtlClockGet()/3000)*1000);//
    UARTCharPutNonBlocking(sim900Uart,'\r');
    UARTCharPutNonBlocking(sim900Uart,'\n');

    receiveSms();

    GPIOPinWrite(GPIO_PORTF_BASE , RED_LED ,0x0);
    GPIOPinWrite(GPIO_PORTF_BASE , GREEN_LED ,0x0);
    GPIOPinWrite(GPIO_PORTF_BASE , BLUE_LED ,0x0);
    sendUartString(sim900Uart, "AT\r\n");


}


void postDataToServer(char * lat,char * lon, char * pulse){
    sendUartString(console,"postFunct\n");
    sendUartString(console,"lat:");sendUartString(console,lat);
    sendUartString(console,"lon:");sendUartString(console,lon);
    sendUartString(console,"pulse:");sendUartString(console,pulse);
    sendUartString(console,"\n");

    GPIOPinWrite(GPIO_PORTF_BASE , GREEN_LED ,0x0);
    GPIOPinWrite(GPIO_PORTF_BASE , BLUE_LED ,0x0);
    GPIOPinWrite(GPIO_PORTF_BASE , RED_LED ,0x0);
    GPIOPinWrite(GPIO_PORTF_BASE , RED_LED ,RED_LED);
    GPIOPinWrite(GPIO_PORTF_BASE , GREEN_LED ,GREEN_LED);
    GPIOPinWrite(GPIO_PORTF_BASE , BLUE_LED ,BLUE_LED);


    int var=0;
    char msj1[]="AT\r\n";
    char msj2[]="AT+SAPBR=3,1,\"CONTYPE\",\"GPRS\"\r\n";
    char msj3[]="AT+SAPBR=3,1,\"APN\",\"www\"\r\n";
    char msj4[]="AT+SAPBR=1,1\r\n";
    char msj5[]="AT+SAPBR=2,1\r\n";
    char msj6[]="AT+HTTPINIT\r\n";
    char msj7[]="AT+HTTPPARA=\"CID\",1\r\n";
    char msj8[]="AT+HTTPPARA=\"URL\",\"http://23.97.183.163:5000/postData\"\r\n";
    //snprintf(msj8,62,"AT+HTTPPARA=\"URL\",\"http://%s/getCircle\r\n",hostname);
    char msj9[]="AT+HTTPPARA=\"CONTENT\",\"text/plain\"\r\n";
    char msj10[]="AT+HTTPDATA=24,10000\r\n";
    /*char data[128];
    for (var = 0; var < 126; ++var) {
        data[var]=var+'0';
    }*/
    char data[24];
    memset(data,1,sizeof(data));
    for (var = 0; var < 9; ++var) {
        data[var]=*lat;
        lat++;
    }
    data[var]=',';var++;
    for (var = var; var < 19; ++var) {
        data[var]=*lon;
        lon++;
    }
    data[var]=',';var++;
    for (var = var; var < 22; ++var) {
        data[var]=*pulse;
        pulse++;
    }

    data[22]='\r';data[23]='\n';
    char msj11[]="AT+HTTPACTION=1\r\n";
    char msj12[]="AT+HTTPTERM\r\n";
    char msj13[]="AT+SAPBR=0,1\r\n";

    sendUartString(sim900Uart,msj1);
    SysCtlDelay((SysCtlClockGet()/3000)*300);//
    sendUartString(sim900Uart,msj2);
    SysCtlDelay((SysCtlClockGet()/3000)*300);//
    sendUartString(sim900Uart,msj3);
    SysCtlDelay((SysCtlClockGet()/3000)*300);//
    sendUartString(sim900Uart,msj4);
    SysCtlDelay((SysCtlClockGet()/3000)*300);//
    sendUartString(sim900Uart,msj5);
    SysCtlDelay((SysCtlClockGet()/3000)*300);//
    sendUartString(sim900Uart,msj6);
    SysCtlDelay((SysCtlClockGet()/3000)*300);//
    sendUartString(sim900Uart,msj7);
    SysCtlDelay((SysCtlClockGet()/3000)*300);//
    sendUartString(sim900Uart,msj8);
    SysCtlDelay((SysCtlClockGet()/3000)*300);//
    sendUartString(sim900Uart,msj9);
    SysCtlDelay((SysCtlClockGet()/3000)*300);//
    sendUartString(sim900Uart,msj10);
    SysCtlDelay((SysCtlClockGet()/3000)*300);//
    sendUartString(sim900Uart,data);
    SysCtlDelay((SysCtlClockGet()/3000)*300);//
    sendUartString(sim900Uart,msj11);
    SysCtlDelay((SysCtlClockGet()/3000)*300);//
    sendUartString(sim900Uart,msj12);
    SysCtlDelay((SysCtlClockGet()/3000)*300);//
    sendUartString(sim900Uart,msj13);
    SysCtlDelay((SysCtlClockGet()/3000)*300);//

    GPIOPinWrite(GPIO_PORTF_BASE , RED_LED ,0x0);
    GPIOPinWrite(GPIO_PORTF_BASE , GREEN_LED ,0x0);
    GPIOPinWrite(GPIO_PORTF_BASE , BLUE_LED ,0x0);
}

void getCircleSizeFromServer(){
    char msj1[]="AT\r\n";
    char msj2[]="AT+SAPBR=3,1,\"CONTYPE\",\"GPRS\"\r\n";
    char msj3[]="AT+SAPBR=3,1,\"APN\",\"www\"\r\n";
    char msj4[]="AT+SAPBR=1,1\r\n";
    char msj5[]="AT+SAPBR=2,1\r\n";
    char msj6[]="AT+HTTPINIT\r\n";
    char msj7[]="AT+HTTPPARA=\"CID\",1\r\n";
    char msj8[]="AT+HTTPPARA=\"URL\",\"http://23.97.183.163:5000/getCircle\"\r\n";
    //snprintf(msj8,62,"AT+HTTPPARA=\"URL\",\"http://%s/getCircle\r\n",hostname);
    char msj9[]="AT+HTTPACTION=0\r\n";
    char msj10[]="AT+HTTPREAD\r\n";
    char msj11[]="AT+SAPBR=0,1\r\n";

    sendUartString(sim900Uart,msj1);
    SysCtlDelay((SysCtlClockGet()/3000)*2000);//
    sendUartString(sim900Uart,msj2);
    SysCtlDelay((SysCtlClockGet()/3000)*2000);//
    sendUartString(sim900Uart,msj3);
    SysCtlDelay((SysCtlClockGet()/3000)*2000);//
    sendUartString(sim900Uart,msj4);
    SysCtlDelay((SysCtlClockGet()/3000)*2000);//
    sendUartString(sim900Uart,msj5);
    SysCtlDelay((SysCtlClockGet()/3000)*2000);//
    sendUartString(sim900Uart,msj6);
    SysCtlDelay((SysCtlClockGet()/3000)*2000);//
    sendUartString(sim900Uart,msj7);
    SysCtlDelay((SysCtlClockGet()/3000)*2000);//
    sendUartString(sim900Uart,msj8);
    SysCtlDelay((SysCtlClockGet()/3000)*2000);//
    sendUartString(sim900Uart,msj9);
    SysCtlDelay((SysCtlClockGet()/3000)*2000);//
    sendUartString(sim900Uart,msj10);
    SysCtlDelay((SysCtlClockGet()/3000)*3000);//
    sendUartString(console,"read\n");
    sendUartString(sim900Uart,msj11);
    SysCtlDelay((SysCtlClockGet()/3000)*2000);//

}

void sendSms(){
    char msj1[]="AT+CMGF=1\r";
    char msj2[]="AT + CMGS = \"+905511934084\"\r\n";
    char msj3[]="The target went beyond the limits.\r";

    sendUartString(sim900Uart,msj1);
    SysCtlDelay((SysCtlClockGet()/3000)*1000);//
    sendUartString(sim900Uart,msj2);
    SysCtlDelay((SysCtlClockGet()/3000)*1000);//
    sendUartString(sim900Uart,msj3);
    SysCtlDelay((SysCtlClockGet()/3000)*1000);//
    UARTCharPutNonBlocking(sim900Uart,(char)26);
    UARTCharPutNonBlocking(sim900Uart,'\r');
    UARTCharPutNonBlocking(sim900Uart,'\n');
    SysCtlDelay((SysCtlClockGet()/3000)*1000);//
    UARTCharPutNonBlocking(sim900Uart,'\r');
    UARTCharPutNonBlocking(sim900Uart,'\n');

}

void receiveSms(){
    char msj1[]="AT+CMGF=1\r";
    char msj2[]="AT+CNMI=1,2,0,0,0\r";
    sendUartString(sim900Uart,msj1);
    SysCtlDelay((SysCtlClockGet()/3000)*100);//
    sendUartString(sim900Uart,msj2);
    SysCtlDelay((SysCtlClockGet()/3000)*100);//
}



void flushUART(){
    while(UARTCharsAvail(sim900Uart)){
        UARTCharGet(sim900Uart);
    }
}

//UART0_BASE    //"deneme"
void sendUartString(uint32_t nBase, char *nData){
    while(*nData!='\0'){
        if(UARTSpaceAvail(nBase)){
            UARTCharPut(nBase,*nData);
            nData++;
            //while(!UARTCharPutNonBlocking(nBase,*nData));//uartcharput tan farkı diğer işlemleri bloke etmeden işlemi gerçekleştrir
            //    nData++;
        }
    }
}

void sendCommandToCamera(uint32_t nBase, uint8_t *nData,int size){
    int var=0;
    for (var = 0; var < size; ++var) {
        if(UARTSpaceAvail(nBase)){
            UARTCharPut(nBase,nData[var]);
        }
    }
}

void pressConfig(){
    GPIOPinTypeGPIOInput(GPIO_PORTF_BASE,GPIO_PIN_4 );
    GPIOPadConfigSet(GPIO_PORTF_BASE,GPIO_PIN_4 ,GPIO_STRENGTH_12MA,GPIO_PIN_TYPE_STD_WPU);
    GPIOIntDisable(GPIO_PORTF_BASE,GPIO_PIN_4 );        // Disable interrupt for PF4 (in case it was enabled)
    GPIOIntClear(GPIO_PORTF_BASE, GPIO_PIN_4);      // Clear pending interrupts for PF4
    GPIOIntRegister(GPIO_PORTF_BASE, Int_PressControl);     // Register our handler function for port F
    GPIOIntTypeSet(GPIO_PORTF_BASE, GPIO_PIN_4,GPIO_FALLING_EDGE);             // Configure PF4 for falling edge trigger
    IntPrioritySet(INT_GPIOP4,0x01);
    GPIOIntEnable(GPIO_PORTF_BASE, GPIO_PIN_4);
}

void cameraConfig(){
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART5);
    UARTConfigSetExpClk(cameraUart,SysCtlClockGet(),19200,UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE |UART_CONFIG_PAR_NONE);

    //UARTFIFODisable(sim900Uart);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
    GPIOPinTypeUART(GPIO_PORTE_BASE, GPIO_PIN_4 | GPIO_PIN_5); // 1 ve 0 pinlerini uart type inde yapma
    GPIOPinConfigure(GPIO_PE5_U5TX);
    GPIOPinConfigure(GPIO_PE4_U5RX);
    UARTIntEnable(cameraUart,UART_INT_RX);
    UARTIntRegister(cameraUart,Int_Camera); //data geldgnde hangı fonksıyon cagırılacagı
    IntEnable(INT_UART5);
    IntMasterEnable();
    UARTEnable(cameraUart);
}

void sim900UartConfig(){
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART4);
    UARTConfigSetExpClk(sim900Uart,SysCtlClockGet(),9600,UART_CONFIG_WLEN_8 | UART_CONFIG_STOP_ONE |UART_CONFIG_PAR_NONE);
    //UARTFIFODisable(sim900Uart);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC);
    GPIOPinTypeUART(GPIO_PORTC_BASE, GPIO_PIN_4 | GPIO_PIN_5); // 1 ve 0 pinlerini uart type inde yapma
    GPIOPinConfigure(GPIO_PC5_U4TX);
    GPIOPinConfigure(GPIO_PC4_U4RX);
    UARTIntEnable(sim900Uart,UART_INT_RX);
    UARTIntRegister(sim900Uart,Int_sim900); //data geldgnde hangı fonksıyon cagırılacagı
    IntEnable(INT_UART4);
    IntMasterEnable();
    IntPrioritySet(INT_UART4,0x02);
    UARTEnable(sim900Uart);
}

void pulseSensorConfig(){
    SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC0);
        SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE);
        GPIOPinTypeADC(GPIO_PORTE_BASE, GPIO_PIN_3);
        ADCSequenceConfigure(ADC0_BASE, 3, ADC_TRIGGER_PROCESSOR, 0);
        ADCSequenceStepConfigure(ADC0_BASE, 3, 0, ADC_CTL_CH0 | ADC_CTL_IE |
                                 ADC_CTL_END);
        ADCSequenceEnable(ADC0_BASE, 3);
        ADCIntClear(ADC0_BASE, 3);
}
void pulseSensorTimerConfig(){
    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);
    TimerConfigure(TIMER0_BASE, TIMER_CFG_PERIODIC);
    TimerLoadSet(TIMER0_BASE, TIMER_A ,SysCtlClockGet()/10);//saniyede 10 defea int gelcek
    TimerIntRegister(TIMER0_BASE , TIMER_A , Int_PulseTimer);
    TimerIntEnable(TIMER0_BASE,TIMER_TIMA_TIMEOUT);
    IntPrioritySet(INT_TIMER0A,0x05);
    TimerEnable(TIMER0_BASE,TIMER_A);
    IntMasterEnable();
}

void postToDataTimerConfig(){
    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER1);
    TimerConfigure(TIMER1_BASE, TIMER_CFG_PERIODIC);
    TimerLoadSet(TIMER1_BASE, TIMER_A ,SysCtlClockGet()*SENDDATADELAY);//saniyede 10 defea int gelcek
    TimerIntRegister(TIMER1_BASE , TIMER_A , Int_PostDataTimer);
    TimerIntEnable(TIMER1_BASE,TIMER_TIMA_TIMEOUT);
    IntPrioritySet(INT_TIMER1A,0x03);
    TimerEnable(TIMER1_BASE,TIMER_A);
}


void setPins(){
    SysCtlClockSet(SYSCTL_SYSDIV_4|SYSCTL_USE_PLL|SYSCTL_XTAL_16MHZ|SYSCTL_OSC_MAIN);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);

    memset(pulse,1,sizeof(pulse));

    InitPCConsole();

    cameraConfig();

    sim900UartConfig();

    gpsSensorConfig();


    pressConfig();

    pulseSensorConfig();
    pulseSensorTimerConfig();

    postToDataTimerConfig();


    GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE,GREEN_LED);
    GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE,BLUE_LED);
    GPIOPinTypeGPIOOutput(GPIO_PORTF_BASE,RED_LED);
}


void
InitPCConsole(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
    //printf("UART Setup Completed 1\n");

    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);
    GPIOPinConfigure(GPIO_PA0_U0RX);
    GPIOPinConfigure(GPIO_PA1_U0TX);
    //printf("UART Setup Completed 2\n");

    UARTConfigSetExpClk(console, SysCtlClockGet(), 115200, UART_CONFIG_PAR_NONE | UART_CONFIG_STOP_ONE | UART_CONFIG_WLEN_8);
    UARTFIFODisable(console);
    //UARTFIFODisable(UART1_BASE);
    UARTEnable(console);

    sendUartString(UART0_BASE, "UART Setup Completed\n");
}

int controlDistanceRange(){
    double dist=(distance(beforeLat,beforeLong,currentLat,currentLong,'K'))*1000;
    if(dist>circleSize){
        return 1;
    }
    else return 0;
}

double deg2rad(double deg){
    return (deg * pi / 180);
}

//40.881657, 29.255639
//40.880471, 29.255655

double rad2deg(double rad){
    return (rad * 180 / pi);
}

double distance(double lat1, double lon1, double lat2, double lon2, char unit){
    double theta, dist;
    if ((lat1 == lat2) && (lon1 == lon2)) {
        return 0;
    }
    else {
        theta = lon1 - lon2;
        dist = sin(deg2rad(lat1)) * sin(deg2rad(lat2)) + cos(deg2rad(lat1)) * cos(deg2rad(lat2)) * cos(deg2rad(theta));
        dist = acos(dist);
        dist = rad2deg(dist);
        dist = dist * 60 * 1.1515;
        switch(unit) {
         case 'M':
           break;
         case 'K':
           dist = dist * 1.609344;
           break;
         case 'N':
           dist = dist * 0.8684;
           break;
        }
            return (dist);
    }
}

/*
void readGPSModule(){
    char c0,GPSValues[100],parseValue[12][20],*token,*saat;
    double latitude=0.0,longitude=0.0,seconds=0.0,result=0.0,minutes=0.0;
    const char comma[2] = ",";
    int index=0,degrees,i=0,j=0;

    memset(GPSValues,0,sizeof(GPSValues));

    while(!UARTCharsAvail(UART2_BASE));
    c0=UARTCharGetNonBlocking(UART2_BASE);

    //gelen data $GPRMC mi?
    if(c0=='$'){
        while(!UARTCharsAvail(UART2_BASE));
        char c1=UARTCharGetNonBlocking(UART2_BASE);
        if(c1=='G'){
            while(!UARTCharsAvail(UART2_BASE));
            char c2=UARTCharGetNonBlocking(UART2_BASE);
            if(c2=='P'){
                while(!UARTCharsAvail(UART2_BASE));
                char c3=UARTCharGetNonBlocking(UART2_BASE);
                if(c3=='R'){
                    while(!UARTCharsAvail(UART2_BASE));
                    char c4=UARTCharGetNonBlocking(UART2_BASE);
                    if(c4=='M'){
                        while(!UARTCharsAvail(UART2_BASE));
                        char c5=UARTCharGetNonBlocking(UART2_BASE);
                        if(c5=='C'){
                            while(!UARTCharsAvail(UART2_BASE));
                            char c6=UARTCharGetNonBlocking(UART2_BASE);
                            if(c6==','){
                                while(!UARTCharsAvail(UART2_BASE));
                                char c7=UARTCharGetNonBlocking(UART2_BASE);


                                //verileri GPSValues arrayine atama.son veri olan checksum a kadar oku(checksum:A*60 gibi)
                                while(c7!='*'){
                                    GPSValues[index]=c7;
                                    //printf("input:%s\n",GPSValues);
                                    //SysCtlDelay((SysCtlClockGet()/3000)*10);//
                                    while(!UARTCharsAvail(UART2_BASE));
                                    c7=UARTCharGetNonBlocking(UART2_BASE);
                                    index++;}

                                //printf("-------------------------------------------------\n");

                                //GPSValues arrayindeki verileri virgul e gore ayirma
                                index=0;
                                token = strtok(GPSValues, comma);
                                while( token != NULL ) {
                                    strcpy(parseValue[index], token);
                                    token = strtok(NULL, comma);
                                    index++;}


                                //parseValue[1] = A ise veri gecerli - V ise gecerli degil
                                if(strcmp(parseValue[1],"A")==0){
                                    latitude=atof(parseValue[2]);
                                    longitude=atof(parseValue[4]);


                                    //latitude hesaplama
                                    degrees=latitude/100;
                                    minutes=latitude-(double)(degrees*100);
                                    seconds=minutes/60.00;
                                    result=degrees+seconds;
                                    sprintf(latitudeResult,"%f", result);


                                    //longitude hesaplama
                                    degrees=longitude/100;
                                    minutes=longitude-(double)(degrees*100);
                                    seconds=minutes/60.00;
                                    result=degrees+seconds;
                                    sprintf(longitudeResult, "%f", result);


                                    //printf("https://www.google.com/maps/place/%s+%s \n",latitudeResult,longitudeResult);
                                    //tarih duzeltme
                                    for(i=0;i<6;i++){
                                        tarih[j]=parseValue[index-2][i];
                                        if(i==1 || i==3){
                                            j++;
                                            tarih[j]='/';}
                                        j++;}
                                    tarih[8]='\0';


                                    //saat düzeltme +3 UTC ayarlama
                                    saat=saatAyarla(parseValue[0]);
                                    j=0;
                                    for(i=0;i<6;i++){
                                        guncelSaat[j]=saat[i];
                                        if(i==1 || i==3){
                                            j++;
                                            guncelSaat[j]=':';}
                                        j++;}
                                    guncelSaat[8]='\0';


                                    sendUartString(console,latitudeResult);sendUartString(console,"\n");
                                    sendUartString(console,longitudeResult);sendUartString(console,"\n");
                                    sendUartString(console,tarih);sendUartString(console,"\n");
                                    sendUartString(console,guncelSaat);sendUartString(console,"\n");

                                    //SysCtlDelay(SysCtlClockGet()/6);
                                }
                                else{
                                    sendUartString(console,"okunuyor\n");

                                //printf("");
                                }
                        }}}}}}}
}

char* saatAyarla(char str[]){
    int num10 = str[0]-'0';
    int num1 = str[1]-'0';
    int saatVerisi=num10*10+num1;

    saatVerisi=saatVerisi+3;
    if(saatVerisi>24){
        saatVerisi=saatVerisi%24;
        if(saatVerisi<10){
            str[0]='0';
            str[1]=saatVerisi+'0';}
        else{
            str[0]=(saatVerisi/10)+'0';
            str[1]=(saatVerisi%10)+'0';}}
    else{
        str[0]=(saatVerisi/10)+'0';
        str[1]=(saatVerisi%10)+'0';}
    return str;
}*/


