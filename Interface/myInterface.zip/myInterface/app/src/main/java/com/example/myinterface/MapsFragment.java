package com.example.myinterface;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URI;
import java.net.URL;
import java.util.Arrays;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * A simple {@link Fragment} subclass.
 */
public class MapsFragment extends Fragment implements OnMapReadyCallback {
    private static final String TAG = "MapsFragment";
    MapsActivity mapsActivity = new MapsActivity();

    String hostname;
    String num;
    int sleepSec=20000;
    Integer mapFlag=0;

    @SuppressLint("ValidFragment")
    public MapsFragment(String hostname,String num,Integer flag) {
        this.num=num;
        this.hostname=hostname;
        this.mapFlag=flag;
    }

    public MapsFragment() {
        // Required empty public constructor
        //requestThread=new requestThread(this);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v=inflater.inflate(R.layout.fragment_maps, container, false);
        return v;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        SupportMapFragment mapFragment = (SupportMapFragment)getChildFragmentManager().findFragmentById(R.id.map1);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mapsActivity.onMapReady(googleMap);
        getterGpsData runnable = new getterGpsData(sleepSec);
        new Thread(runnable).start();
    }
    
    class getterGpsData implements Runnable {
        int sleepSec;

        double lat=0.0;
        double lon=0.0;
        int flag=0;

        getterGpsData(int seconds) {
            this.sleepSec = seconds;
        }

        String convertStreamToString(java.io.InputStream is) {
            java.util.Scanner s = new java.util.Scanner(is).useDelimiter("\\A");
            return s.hasNext() ? s.next() : "";
        }

        void getData(){
            try {
                URL url = new URL(hostname+"/getLocation");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();

                conn.setReadTimeout(10000 /* milliseconds */);
                conn.setConnectTimeout(15000 /* milliseconds */);
                conn.setRequestMethod("GET");
                conn.setDoInput(true);
                // Starts the query
                conn.connect();
                InputStream stream = conn.getInputStream();

                String t = convertStreamToString(stream);
                System.out.println("SUCCES::"+t);
                List<String> mylist = Arrays.asList(t.split(","));
                System.out.println("mylist:"+mylist);

                if(lat!=Double.parseDouble(mylist.get(0)) && lon!=Double.parseDouble(mylist.get(1))){
                    System.out.println("Succes Assignment");
                    lat=Double.parseDouble(mylist.get(0));
                    lon=Double.parseDouble(mylist.get(1));
                    if(lat!=0.0 && lon!=0.0){
                        System.out.println("FLAG 1");
                        flag=1;
                    }
                    else{
                        System.out.println("Location is zero");
                    }
                }
                else flag=0;

                stream.close();

            }catch(SocketTimeoutException e){

            }
            catch (Exception e) {
                e.printStackTrace();
            }


        }


        @Override
        public void run() {
            while(true){
                getData();
                if(flag==1){
                    mapsActivity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            System.out.println("addMarker");
                            System.out.println("lat:"+lat+",lon:"+lon);

                            if(mapFlag==0) mapsActivity.before.setVisible(false);

                            mapsActivity.addMarker(lat, lon);
                            System.out.println("FLAG is 0");
                            flag=0;
                        }
                    });
                }else
                    System.out.println("Not updated location");

                try {
                    Thread.sleep(sleepSec);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}


 /*
            OkHttpClient client = new OkHttpClient();
            String url = hostname+"/getLocation";
            Request request = new Request.Builder()
                    .url(url)
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    e.printStackTrace();
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (response.isSuccessful()) {
                        assert response.body() != null;
                        System.out.println("SUCCESS :"+response.body().string());
                        String t=response.body().string();
                        List<String> mylist = Arrays.asList(t.split(","));

                        if(lat!=Double.parseDouble(mylist.get(0)) && lon!=Double.parseDouble(mylist.get(1))){

                            lat=Double.parseDouble(mylist.get(0));
                            lon=Double.parseDouble(mylist.get(1));
                            if(lat!=0 && lon!=0) flag=1;
                            else
                                System.out.println("Location is zero");
                        }else flag=0;

                    }
                }
            });*/