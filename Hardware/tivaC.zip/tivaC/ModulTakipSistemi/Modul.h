/*
 * Modul.h
 *
 *  Created on: 11 May 2019
 *      Author: xyz
 */

#ifndef MODUL_H_
#define MODUL_H_

#include <stdint.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include "inc/hw_memmap.h"
#include "inc/hw_ints.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/uart.h"
#include "driverlib/pin_map.h"
#include "driverlib/adc.h"
#include "driverlib/timer.h"
#include <math.h>

/*
 * ------------------------------------------DEFINE MACRO
 */
#define PULSETHRESHOLD 2300
#define SENDDATADELAY 40

#define RED_LED GPIO_PIN_1
#define BLUE_LED GPIO_PIN_2
#define GREEN_LED GPIO_PIN_3

#define cameraUart UART5_BASE
#define sim900Uart UART4_BASE
#define console UART0_BASE
#define sysClock (SysCtlClockGet()/3000)*500;//500 ms gecikme

#define pi 3.14159265358979323846

/**
 * ----------------------------------------STATIC GLOBAL VARIABLES
 */

///
static char hostname[20]="";
static int smsFlag=0;

//sim900 variables
static char recieveMessage[64];
static int sim900Index = 0;
static int readFlag = 0;
static int callStatusFlag = 0;//0: nothing , 1:came Call ,2:on Call

///pulse sensor variables
static bool toggle=false;
static uint32_t AdcValues[1];
static uint32_t Temp;
static uint8_t pulse=20;

///gps variable
static double beforeLat=0.0;
static double beforeLong=0.0;
static double currentLat=0.0;
static double currentLong=0.0;
static int circleSize=0;
static char circleFlag = 'n';

char latitudeResult[10];
char longitudeResult[10];
static char tarih[9];
static char guncelSaat[9];
static uint8_t gpsFlagControl=0;

///camera variable
static int cameraIndex = 0;
static char cameraResponse[128];
/*
 * ----------------------------------------FUNCTION PROTOTYPES
 */

///Config Functions
void setPins();
void cameraConfig();
void sim900UartConfig();
void pulseSensorConfig();
void  pressConfig();

void pulseSensorTimerConfig();
void postToDataTimerConfig();

void Int_Camera(void);
void Int_PressControl(void);
void Int_sim900(void);
void InitPCConsole(void);

void Int_PostDataTimer(void);
void Int_PulseTimer(void);


//Functions of pressingButton
void answerCall();
void makeCall();
void hangsUpCall();
int isCall(char *message);
int isNo(char *message);
int isCircleSet(char *message);

//camera functions
void sendCommandToCamera(uint32_t nBase, uint8_t *nData,int size);
///Some sim900 commands
void sendUartString(uint32_t nBase, char *nData);
void sendSms();
void receiveSms();
void getCircleSizeFromServer();
void postDataToServer(char * lat,char * lon, char * pulse);
void postDataToInterface(char * lat,char * lon, char * pulse);

///Gps Sensors Functions
char* saatAyarla(char str[]);
void readGPSModule();

///Led Function
void ledLight(uint8_t led,int millisec);

///Distance Functions
int controlDistanceRange();
double deg2rad(double);
double rad2deg(double);
double distance(double lat1, double lon1, double lat2, double lon2, char unit);

#endif /* MODUL_H_ */
