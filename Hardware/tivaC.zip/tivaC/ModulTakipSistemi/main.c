#include <stdint.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>

#include "inc/hw_memmap.h"
#include "inc/hw_ints.h"
#include "inc/hw_types.h"

#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/uart.h"
#include "driverlib/pin_map.h"
#include "driverlib/adc.h"
#include "driverlib/timer.h"

#include "utils/uartstdio.h"
#include <inttypes.h>

#include "Modul.h"

void Int_Gps(void);
void gpsSensorConfig();

char* saatAyarla(char str[]);
void readGPSModule();
void ayarCek();

/**
 * PROBLEMLER
 * bool data type kullanma !!!!!!!!!!!!!!!!!!!!!!!!!
 * pulse verisi server a veri yollarken abuk subuk gelıyor static felan ayarla onu
 * callStatusFlag calısıyo galıba ondan ornek al
 */

int main(void)
{
    ///AYARLARA DOKUNMAAA. EKSTRA OLANLAR GPS INTERRUPTI ICIN
    ayarCek();
    setPins();
    //char s[32];

    SysCtlDelay(20000000);
    sendUartString(console, "take picture\n");
    sendUartString(cameraUart, "$");


    SysCtlDelay(80000000);
        sendUartString(console, "take picture2\n");
        sendUartString(cameraUart, "$");
/*
    uint32_t sim = IntPriorityGet(INT_UART4);
    sprintf(s,"sim:%ld\n",sim);
    sendUartString(console,s);

    uint32_t gps = IntPriorityGet( INT_UART2 );
    sprintf(s,"gps:%ld\n",gps);
    sendUartString(console,s);

    uint32_t adcTim = IntPriorityGet( INT_TIMER0A );
    sprintf(s,"adcTim:%ld\n",adcTim);
    sendUartString(console,s);

    sendUartString(sim900Uart, "AT\r\n");
    sendUartString(console, "AT is sent\n");
    SysCtlDelay(200000000);

    char msj1[]="AT+CMGF=1\r";
    char msj2[]="AT+CNMI=1,2,0,0,0\r";
    sendUartString(sim900Uart, msj1);
    SysCtlDelay(20000000);
    sendUartString(sim900Uart, msj2);

    SysCtlDelay(20000000);
    sendUartString(console, "Receive SMS Command is sent\n");
    //$GPRMC, 200751.00, A, 4047.32510 ,N, 02929.63031, E,9.879,105.80, 301117, ,,A*6C*/
    while(1){
        //SysCtlDelay(20000000);
        //postDataToServer("40.656555","29.689734","46");
        //readGPSModule();

        /*if(circleFlag=='y'){
            if(controlDistanceRange()){
                beforeLat=0.0;
                beforeLong=0.0;
                circleSize=0;
                sendSms();
                circleFlag='n';
            }
        }*/
    }
    //UARTDisable(UART1_BASE);

}

void ayarCek(){
    latitudeResult[0]='4';longitudeResult[0]='2';
    latitudeResult[1]='0';longitudeResult[1]='9';
    latitudeResult[2]='.';longitudeResult[2]='.';
    latitudeResult[3]='8';longitudeResult[3]='3';
    latitudeResult[4]='0';longitudeResult[4]='5';
    latitudeResult[5]='8';longitudeResult[5]='6';
    latitudeResult[6]='2';longitudeResult[6]='1';
    latitudeResult[7]='2';longitudeResult[7]='2';
    latitudeResult[8]='9';longitudeResult[8]='6';

}

void Int_Gps(void){
    readGPSModule();
    UARTIntClear(UART2_BASE, UART_INT_RX);
}

void gpsSensorConfig(){
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD);
    GPIOPinConfigure(GPIO_PD6_U2RX);
    GPIOPinConfigure(GPIO_PD7_U2TX);
    GPIOPinTypeUART(GPIO_PORTD_BASE,GPIO_PIN_6|GPIO_PIN_7);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART2);
    UARTConfigSetExpClk(UART2_BASE,SysCtlClockGet(),9600,(UART_CONFIG_WLEN_8 | UART_CONFIG_PAR_NONE | UART_CONFIG_STOP_ONE));
    UARTIntEnable(UART2_BASE,UART_INT_RX);
    UARTIntRegister(UART2_BASE,Int_Gps); //data geldgnde hangı fonksıyon cagırılacagı
    IntEnable(INT_UART2);
    //IntMasterEnable();
    IntPrioritySet(INT_UART2,0x04);
    UARTEnable(UART2_BASE);
}

void readGPSModule(){
    char c0,GPSValues[100],parseValue[12][20],*token,*saat;
    double latitude=0.0,longitude=0.0,seconds=0.0,result=0.0,minutes=0.0;
    const char comma[2] = ",";
    int index=0,degrees,i=0,j=0;

    memset(GPSValues,0,sizeof(GPSValues));

    while(!UARTCharsAvail(UART2_BASE));
    c0=UARTCharGetNonBlocking(UART2_BASE);

    //gelen data $GPRMC mi?
    if(c0=='$'){
        while(!UARTCharsAvail(UART2_BASE));
        char c1=UARTCharGetNonBlocking(UART2_BASE);
        if(c1=='G'){
            while(!UARTCharsAvail(UART2_BASE));
            char c2=UARTCharGetNonBlocking(UART2_BASE);
            if(c2=='P'){
                while(!UARTCharsAvail(UART2_BASE));
                char c3=UARTCharGetNonBlocking(UART2_BASE);
                if(c3=='R'){
                    while(!UARTCharsAvail(UART2_BASE));
                    char c4=UARTCharGetNonBlocking(UART2_BASE);
                    if(c4=='M'){
                        while(!UARTCharsAvail(UART2_BASE));
                        char c5=UARTCharGetNonBlocking(UART2_BASE);
                        if(c5=='C'){
                            while(!UARTCharsAvail(UART2_BASE));
                            char c6=UARTCharGetNonBlocking(UART2_BASE);
                            if(c6==','){
                                while(!UARTCharsAvail(UART2_BASE));
                                char c7=UARTCharGetNonBlocking(UART2_BASE);

                                //verileri GPSValues arrayine atama.son veri olan checksum a kadar oku(checksum:A*60 gibi)
                                while(c7!='*'){
                                    GPSValues[index]=c7;
                                    //printf("input:%s\n",GPSValues);
                                    //SysCtlDelay((SysCtlClockGet()/3000)*10);//
                                    while(!UARTCharsAvail(UART2_BASE));
                                    c7=UARTCharGetNonBlocking(UART2_BASE);
                                    index++;}

                                //printf("-------------------------------------------------\n");

                                //GPSValues arrayindeki verileri virgul e gore ayirma
                                index=0;
                                token = strtok(GPSValues, comma);
                                while( token != NULL ) {
                                    strcpy(parseValue[index], token);
                                    token = strtok(NULL, comma);
                                    index++;}


                                //parseValue[1] = A ise veri gecerli - V ise gecerli degil
                                if(strcmp(parseValue[1],"A")==0){
                                    latitude=atof(parseValue[2]);
                                    longitude=atof(parseValue[4]);
                                    if(circleFlag=='y'){
                                        beforeLat=latitude;
                                        beforeLong=longitude;
                                    }
                                    if(beforeLat==0.0 && beforeLong==0.0){
                                        currentLat=latitude;
                                        currentLong=longitude;
                                    }


                                    //latitude hesaplama
                                    degrees=latitude/100;
                                    minutes=latitude-(double)(degrees*100);
                                    seconds=minutes/60.00;
                                    result=degrees+seconds;
                                    sprintf(latitudeResult,"%f", result);


                                    //longitude hesaplama
                                    degrees=longitude/100;
                                    minutes=longitude-(double)(degrees*100);
                                    seconds=minutes/60.00;
                                    result=degrees+seconds;
                                    sprintf(longitudeResult, "%f", result);


                                    //printf("https://www.google.com/maps/place/%s+%s \n",latitudeResult,longitudeResult);
                                    //tarih duzeltme
                                    for(i=0;i<6;i++){
                                        tarih[j]=parseValue[index-2][i];
                                        if(i==1 || i==3){
                                            j++;
                                            tarih[j]='/';}
                                        j++;}
                                    tarih[8]='\0';


                                    //saat düzeltme +3 UTC ayarlama
                                    saat=saatAyarla(parseValue[0]);
                                    j=0;
                                    for(i=0;i<6;i++){
                                        guncelSaat[j]=saat[i];
                                        if(i==1 || i==3){
                                            j++;
                                            guncelSaat[j]=':';}
                                        j++;}
                                    guncelSaat[8]='\0';

                                    sendUartString(console,latitudeResult);sendUartString(console,"\n");
                                    sendUartString(console,longitudeResult);sendUartString(console,"\n");
                                    sendUartString(console,tarih);sendUartString(console,"\n");
                                    sendUartString(console,guncelSaat);sendUartString(console,"\n");

                                    gpsFlagControl=1;
                                    char s[12];sprintf(s,"gpsFlag:%ld\n",gpsFlagControl);
                                    sendUartString(console,s);


                                    //SysCtlDelay((SysCtlClockGet()/3000)*50);
                                }
                                else{
                                    sendUartString(console,"okunuyor\n");
                                    char s[12];sprintf(s,"gpsFlag:%ld\n",gpsFlagControl);
                                                sendUartString(console,s);
                                    //ledLight(RED_LED, 200);

                                //printf("");
                                }
                        }}}}}}}
}

char* saatAyarla(char str[]){
    int num10 = str[0]-'0';
    int num1 = str[1]-'0';
    int saatVerisi=num10*10+num1;

    saatVerisi=saatVerisi+3;
    if(saatVerisi>24){
        saatVerisi=saatVerisi%24;
        if(saatVerisi<10){
            str[0]='0';
            str[1]=saatVerisi+'0';}
        else{
            str[0]=(saatVerisi/10)+'0';
            str[1]=(saatVerisi%10)+'0';}}
    else{
        str[0]=(saatVerisi/10)+'0';
        str[1]=(saatVerisi%10)+'0';}
    return str;
}

